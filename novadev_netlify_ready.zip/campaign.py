#!/usr/bin/env python3
"""
Nova Dev — Email Marketing Campaign Script
==========================================
Sends personalised HTML emails to moving company leads.
- Validates & deduplicates contacts from CSV
- Different messages per issue type / activity
- Random delays between sends to avoid spam flags
- Unsubscribe link in every email
- SMTP via mail.novatvhub.com

USAGE:
    1. Set LANDING_PAGE_URL to your live Netlify domain (update before running!)
    2. Run:  python3 campaign.py
    3. The script saves progress to sent_log.json so it can be resumed safely.

⚠  DO NOT RUN until you update LANDING_PAGE_URL with the real domain.
"""

import csv
import json
import os
import random
import re
import smtplib
import time
import hashlib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime

# ─────────────────────────────────────────────
#  CONFIG  ← update LANDING_PAGE_URL before run
# ─────────────────────────────────────────────
SMTP_HOST        = "mail.novatvhub.com"
SMTP_PORT        = 587                          # TLS; try 465 for SSL if 587 fails
SMTP_USER        = "admin@novatvhub.com"
SMTP_PASS        = "1allahArrahman"
FROM_NAME        = "Nova Dev | Web & Marketing"
FROM_EMAIL       = "admin@novatvhub.com"

LANDING_PAGE_URL = "https://YOUR-NEW-DOMAIN.netlify.app"   # ← REPLACE THIS

CSV_FILE         = "EN_Moving_1000_v2.csv"
SENT_LOG         = "sent_log.json"
FAILED_LOG       = "failed_log.json"

# Delay range (seconds) between emails — keeps you safe from spam filters
DELAY_MIN = 45
DELAY_MAX = 120

# Daily send cap (set to None for unlimited)
DAILY_CAP = 150

# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────

def load_sent_log():
    if os.path.exists(SENT_LOG):
        with open(SENT_LOG) as f:
            return set(json.load(f))
    return set()

def save_sent_log(sent_ids):
    with open(SENT_LOG, "w") as f:
        json.dump(list(sent_ids), f, indent=2)

def load_failed_log():
    if os.path.exists(FAILED_LOG):
        with open(FAILED_LOG) as f:
            return json.load(f)
    return []

def save_failed_log(failures):
    with open(FAILED_LOG, "w") as f:
        json.dump(failures, f, indent=2)

def is_valid_email(email: str) -> bool:
    """Basic RFC-5322 ish validation."""
    pattern = r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email.strip())) if email else False

def make_unsubscribe_token(email: str) -> str:
    """Deterministic token for unsubscribe link (based on email hash)."""
    return hashlib.sha256(email.lower().strip().encode()).hexdigest()[:20]

def load_contacts(csv_file: str):
    """Load, validate, and deduplicate contacts from CSV."""
    contacts = []
    seen_emails = set()
    seen_companies = set()
    invalid = []
    duplicates = []

    with open(csv_file, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            email   = row.get("Email", "").strip().lower()
            company = row.get("Company_Name", "").strip().lower()
            cid     = row.get("ID", "").strip()

            # Validate
            if not is_valid_email(email):
                invalid.append({"id": cid, "email": email, "reason": "invalid_format"})
                continue

            # Deduplicate by email
            if email in seen_emails:
                duplicates.append({"id": cid, "email": email, "reason": "dup_email"})
                continue

            # Deduplicate by company name (optional — keeps first occurrence)
            if company and company in seen_companies:
                duplicates.append({"id": cid, "email": email, "reason": "dup_company"})
                continue

            seen_emails.add(email)
            if company:
                seen_companies.add(company)

            contacts.append(row)

    print(f"✅  Loaded:      {len(contacts)} valid contacts")
    print(f"⚠️   Invalid:     {len(invalid)}")
    print(f"🔁  Duplicates:  {len(duplicates)}")
    return contacts

# ─────────────────────────────────────────────
#  EMAIL TEMPLATES
# ─────────────────────────────────────────────

BRAND_COLOR  = "#1a73e8"
ACCENT_COLOR = "#00c2a8"

def base_email(body_html: str, company: str, email: str) -> str:
    token = make_unsubscribe_token(email)
    unsub_url = f"{LANDING_PAGE_URL}/unsubscribe?token={token}&email={email}"
    return f"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<style>
  body    {{ font-family:'Segoe UI',Arial,sans-serif; background:#f0f4ff; margin:0; padding:0; color:#1a1a2e; }}
  .wrap   {{ max-width:620px; margin:30px auto; background:#fff; border-radius:16px;
             box-shadow:0 4px 24px rgba(26,115,232,.12); overflow:hidden; }}
  .hdr    {{ background:linear-gradient(135deg,{BRAND_COLOR},{ACCENT_COLOR});
             padding:28px 36px 22px; text-align:center; }}
  .hdr .logo-txt {{ font-size:26px; font-weight:900; color:#fff; letter-spacing:-0.5px; }}
  .hdr .logo-txt em {{ color:#b3f0e8; font-style:normal; }}
  .hdr .tagline   {{ font-size:11px; color:rgba(255,255,255,.65); letter-spacing:1px;
                     text-transform:uppercase; margin-top:4px; }}
  .body   {{ padding:36px 40px; }}
  .body h2 {{ font-size:1.35rem; font-weight:800; margin-bottom:16px; color:#0d1b2a; }}
  .body p  {{ font-size:0.95rem; line-height:1.72; color:#4a5568; margin-bottom:14px; }}
  .body ul {{ padding-left:20px; margin-bottom:14px; }}
  .body li {{ font-size:0.93rem; line-height:1.7; color:#4a5568; }}
  .cta-btn {{ display:block; width:fit-content; margin:28px auto 8px;
              background:linear-gradient(135deg,{BRAND_COLOR},{ACCENT_COLOR});
              color:#fff; text-decoration:none; padding:16px 38px;
              border-radius:50px; font-weight:800; font-size:1rem;
              box-shadow:0 6px 24px rgba(26,115,232,.3); text-align:center; }}
  .ftr     {{ background:#0d1b2a; padding:22px 36px; text-align:center;
              font-size:0.78rem; color:#5a7a9a; }}
  .ftr a   {{ color:{ACCENT_COLOR}; text-decoration:none; }}
  .unsub   {{ margin-top:10px; font-size:0.72rem; color:#3a5a7a; }}
  .divider {{ border:none; border-top:1.5px solid #e8edf5; margin:24px 0; }}
  @media(max-width:480px){{ .body{{padding:24px 20px;}} .hdr{{padding:20px;}} }}
</style>
</head>
<body>
<div class="wrap">
  <div class="hdr">
    <div class="logo-txt">Nova<em>Dev</em></div>
    <div class="tagline">Web Development &amp; Digital Marketing</div>
  </div>
  <div class="body">
    {body_html}
    <a class="cta-btn" href="{LANDING_PAGE_URL}#free-audit">
      🎯 Claim Your Free Website Audit
    </a>
    <hr class="divider"/>
    <p style="font-size:0.82rem;color:#6b7280;text-align:center;">
      Questions? Reply to this email or write us at
      <a href="mailto:{FROM_EMAIL}" style="color:{BRAND_COLOR};">{FROM_EMAIL}</a>
    </p>
  </div>
  <div class="ftr">
    <strong style="color:#fff;">Nova Dev</strong> — WordPress &amp; Next.js Development &amp; Digital Marketing<br/>
    <a href="{LANDING_PAGE_URL}">novadev.com</a> ·
    <a href="mailto:{FROM_EMAIL}">{FROM_EMAIL}</a>
    <div class="unsub">
      You're receiving this because your company was identified as a potential fit for our services.<br/>
      <a href="{unsub_url}">Unsubscribe</a> · <a href="{LANDING_PAGE_URL}/privacy.html">Privacy Policy</a>
    </div>
  </div>
</div>
</body>
</html>
"""

# ── Template A: WCAG / Accessibility issues ──
def tpl_accessibility(row: dict) -> tuple:
    company = row["Company_Name"]
    city    = row.get("City", "")
    subject = f"Quick fix that could cost {company} customers every day"
    body = f"""
<h2>Hi {company} team 👋</h2>
<p>I came across your website and noticed some <strong>accessibility issues</strong> that may be causing visitors — and potential customers — to leave before requesting a quote.</p>
<p>Things like low-contrast text, missing alt tags, and WCAG failures don't just frustrate users — they also <strong>hurt your Google rankings</strong>.</p>
<p><strong>Here's what a free audit from Nova Dev includes:</strong></p>
<ul>
  <li>✅ Accessibility & WCAG compliance report</li>
  <li>✅ Mobile responsiveness check</li>
  <li>✅ Page speed & Core Web Vitals score</li>
  <li>✅ Local SEO analysis for {city or 'your area'}</li>
  <li>✅ Actionable recommendations — no strings attached</li>
</ul>
<p>We build WordPress &amp; Next.js websites for moving companies that <strong>convert visitors into paying customers</strong>. Many of our clients 3× their leads within 60 days of launch.</p>
<p>The audit is <strong>100% free</strong> and takes us less than 24 hours to deliver.</p>
"""
    return subject, body

# ── Template B: Poor colour contrast / UX ──
def tpl_ux(row: dict) -> tuple:
    company = row["Company_Name"]
    city    = row.get("City", "")
    subject = f"Is your website design losing {company} quotes?"
    body = f"""
<h2>Hello {company} 👋</h2>
<p>First impressions matter — especially online. We reviewed your website and spotted some <strong>UX and design issues</strong> (poor colour contrast, confusing navigation, unclear CTAs) that likely cause visitors to leave without requesting a quote.</p>
<p>In the moving industry, <strong>70%+ of customers compare 3+ companies online</strong> before deciding. A dated or confusing site sends them straight to your competitor.</p>
<p><strong>Nova Dev offers a 100% free website audit</strong> that covers:</p>
<ul>
  <li>🎨 UX & design quality review</li>
  <li>📱 Mobile experience analysis</li>
  <li>⚡ Speed & performance score</li>
  <li>🗺️ Local SEO check for {city or 'your city'}</li>
  <li>📊 Conversion rate opportunities</li>
</ul>
<p>We specialise in WordPress and Next.js sites built specifically for moving companies — clean, fast, and built to convert.</p>
"""
    return subject, body

# ── Template C: Missing images / poor visual quality ──
def tpl_images(row: dict) -> tuple:
    company = row["Company_Name"]
    subject = f"Your website visuals may be costing {company} trust"
    body = f"""
<h2>Hi {company} team 👋</h2>
<p>We noticed your website is missing quality images or has low-resolution visuals. In a service-based business like moving, <strong>customers trust what they can see</strong> — professional photos, team shots, and clean design build confidence instantly.</p>
<p>Without compelling visuals, potential customers may assume you're not established — and book with someone else.</p>
<p><strong>Our free audit will show you exactly:</strong></p>
<ul>
  <li>📸 Where images are missing or underperforming</li>
  <li>🏆 How your site compares to top competitors in your area</li>
  <li>🚀 Quick wins to improve trust and conversions immediately</li>
  <li>🔍 Full SEO and technical review</li>
</ul>
<p>Nova Dev rebuilds and launches moving company websites in as little as <strong>2 weeks</strong>. The free audit is the perfect first step.</p>
"""
    return subject, body

# ── Template D: No social media / tiny font / generic ──
def tpl_generic(row: dict) -> tuple:
    company  = row["Company_Name"]
    city     = row.get("City", "")
    issue    = row.get("Issue_Detected", "website issues")
    subject  = f"We found something on {company}'s website worth fixing"
    body = f"""
<h2>Hello {company} 👋</h2>
<p>We did a quick review of your website and identified <strong>{issue.lower()}</strong> that could be affecting your ability to attract and convert new customers online.</p>
<p>In the competitive moving market in {city or 'your area'}, having a <strong>fast, modern, and conversion-optimised website</strong> is no longer optional — it's the difference between a full schedule and an empty truck.</p>
<p><strong>Our free audit delivers:</strong></p>
<ul>
  <li>✅ A full 12-point website analysis</li>
  <li>✅ Specific, prioritised recommendations</li>
  <li>✅ Competitor benchmarking</li>
  <li>✅ Zero cost, zero commitment</li>
</ul>
<p>We're Nova Dev — WordPress &amp; Next.js specialists for the moving industry. We'd love to help {company} get more leads online.</p>
"""
    return subject, body

# ── Template E: New website / from scratch ──
def tpl_new_site(row: dict) -> tuple:
    company = row["Company_Name"]
    city    = row.get("City", "")
    subject = f"Does {company} have the website it deserves?"
    body = f"""
<h2>Hi {company} 👋</h2>
<p>A lot of great moving companies in {city or 'the US'} are being held back by websites that don't represent the quality of their service — or don't have a professional site at all.</p>
<p><strong>Nova Dev builds moving company websites from scratch</strong> — WordPress or Next.js — designed to rank on Google, look stunning on mobile, and convert visitors into booked jobs.</p>
<p><strong>What you get with every Nova Dev site:</strong></p>
<ul>
  <li>🚀 Sub-2-second load times</li>
  <li>📱 100% mobile responsive</li>
  <li>🔍 Local SEO setup from day one</li>
  <li>📝 Professional copywriting included</li>
  <li>🔒 SSL, security & GDPR compliance</li>
  <li>📞 Click-to-call & instant quote forms</li>
</ul>
<p>Start with a <strong>100% free website audit</strong> — we'll show you exactly what you need and how we can help. No pressure, no obligations.</p>
"""
    return subject, body

# ── Template selector ──
def select_template(row: dict) -> tuple:
    issue    = row.get("Issue_Detected", "").lower()
    activity = row.get("Activity_Type", "").lower()

    if "accessibility" in issue or "wcag" in issue:
        return tpl_accessibility(row)
    elif "colour" in issue or "color" in issue or "ux" in issue or "contrast" in issue:
        return tpl_ux(row)
    elif "image" in issue or "visual" in issue:
        return tpl_images(row)
    elif "no website" in issue or "missing website" in issue or row.get("Website_URL","").strip() in ("","N/A","n/a"):
        return tpl_new_site(row)
    else:
        return tpl_generic(row)

# ─────────────────────────────────────────────
#  SMTP SENDER
# ─────────────────────────────────────────────

def send_email(to_email: str, to_name: str, subject: str, html_body: str) -> bool:
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = f"{FROM_NAME} <{FROM_EMAIL}>"
    msg["To"]      = to_email
    msg["Reply-To"] = FROM_EMAIL
    # Anti-spam headers
    msg["List-Unsubscribe"] = f"<mailto:{FROM_EMAIL}?subject=UNSUBSCRIBE>"
    msg["X-Mailer"] = "NovaDevMailer/1.0"

    # Plain text fallback
    plain = re.sub(r'<[^>]+>', '', html_body).strip()
    msg.attach(MIMEText(plain, "plain", "utf-8"))
    msg.attach(MIMEText(html_body, "html", "utf-8"))

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30) as server:
            server.ehlo()
            server.starttls()
            server.ehlo()
            server.login(SMTP_USER, SMTP_PASS)
            server.sendmail(FROM_EMAIL, [to_email], msg.as_string())
        return True
    except smtplib.SMTPRecipientsRefused as e:
        print(f"    ❌ Recipient refused: {to_email} — {e}")
        return False
    except smtplib.SMTPAuthenticationError as e:
        print(f"    🔑 Auth error: {e}")
        raise   # Fatal — stop campaign
    except Exception as e:
        print(f"    ⚠️  Send error ({to_email}): {e}")
        return False

# ─────────────────────────────────────────────
#  MAIN CAMPAIGN LOOP
# ─────────────────────────────────────────────

def run_campaign():
    print("\n" + "="*55)
    print("  Nova Dev Email Campaign — Starting")
    print("="*55)

    if LANDING_PAGE_URL == "https://YOUR-NEW-DOMAIN.netlify.app":
        print("\n⛔  STOP: You must update LANDING_PAGE_URL before running.")
        print("         Open campaign.py and replace the placeholder URL.\n")
        return

    contacts = load_contacts(CSV_FILE)
    sent_ids = load_sent_log()
    failures = load_failed_log()

    todo = [c for c in contacts if c.get("ID") not in sent_ids]
    print(f"📧  Remaining to send: {len(todo)}")
    print(f"✅  Already sent:      {len(sent_ids)}\n")

    sent_today  = 0
    total_sent  = 0
    total_failed = 0

    for i, row in enumerate(todo, 1):
        if DAILY_CAP and sent_today >= DAILY_CAP:
            print(f"\n📅  Daily cap of {DAILY_CAP} reached. Re-run tomorrow to continue.")
            break

        cid     = row.get("ID", f"row_{i}")
        email   = row.get("Email", "").strip().lower()
        company = row.get("Company_Name", "Company")
        city    = row.get("City", "")

        if not is_valid_email(email):
            print(f"  [{i}] ⛔  Skip {cid} — invalid email: {email}")
            continue

        subject, body_html = select_template(row)
        full_html = base_email(body_html, company, email)

        print(f"  [{i}/{len(todo)}] 📤  {company} <{email}> — {subject[:55]}…")

        success = send_email(email, company, subject, full_html)

        if success:
            sent_ids.add(cid)
            sent_today  += 1
            total_sent  += 1
            print(f"         ✅  Sent!")
            save_sent_log(sent_ids)
        else:
            total_failed += 1
            failures.append({
                "id": cid, "email": email, "company": company,
                "timestamp": datetime.utcnow().isoformat()
            })
            save_failed_log(failures)

        # Respectful delay
        delay = random.uniform(DELAY_MIN, DELAY_MAX)
        print(f"         ⏱️   Waiting {delay:.0f}s before next send…\n")
        time.sleep(delay)

    print("\n" + "="*55)
    print(f"  Campaign session complete!")
    print(f"  ✅ Sent:   {total_sent}")
    print(f"  ❌ Failed: {total_failed}")
    print(f"  📋 Remaining: {len(todo) - total_sent - total_failed}")
    print("="*55 + "\n")


if __name__ == "__main__":
    run_campaign()
