/* ============================================================
   Nova Dev — Netlify Serverless Function
   Handles contact form submissions via SMTP (nodemailer)
   ============================================================ */

const nodemailer = require('nodemailer');

exports.handler = async function (event) {
  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  // Parse body (JSON or URL-encoded)
  let fields = {};
  try {
    const ct = (event.headers['content-type'] || '').toLowerCase();
    if (ct.includes('application/json')) {
      fields = JSON.parse(event.body);
    } else {
      // URL-encoded
      new URLSearchParams(event.body).forEach((v, k) => { fields[k] = v; });
    }
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid request body' }) };
  }

  const { fname = '', lname = '', email = '', company = '', website = '', phone = '', service = '', message = '' } = fields;

  // ── SMTP Transporter ──
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'mail.novatvhub.com',
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: false, // STARTTLS on port 587
    auth: {
      user: process.env.SMTP_USER || 'admin@novatvhub.com',
      pass: process.env.SMTP_PASS,
    },
    tls: { rejectUnauthorized: false },
  });

  // ── Email to YOU (notification) ──
  const notifMail = {
    from: `"Nova Dev Contact Form" <admin@novatvhub.com>`,
    to:   'admin@novatvhub.com',
    replyTo: email,
    subject: `🚀 New Audit Request — ${company}`,
    html: `
      <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;background:#f8f9fa;border-radius:8px;">
        <div style="background:#0d1b2a;padding:20px;border-radius:8px 8px 0 0;text-align:center;">
          <h2 style="color:#00c2a8;margin:0;">🚀 New Free Audit Request</h2>
          <p style="color:#fff;margin:5px 0 0;">Nova Dev — Landing Page Form</p>
        </div>
        <div style="background:#fff;padding:25px;border-radius:0 0 8px 8px;border:1px solid #e0e0e0;">
          <table style="width:100%;border-collapse:collapse;">
            <tr><td style="padding:8px 0;color:#666;width:140px;"><strong>Name</strong></td><td style="padding:8px 0;">${fname} ${lname}</td></tr>
            <tr style="background:#f8f9fa;"><td style="padding:8px;color:#666;"><strong>Email</strong></td><td style="padding:8px;"><a href="mailto:${email}">${email}</a></td></tr>
            <tr><td style="padding:8px 0;color:#666;"><strong>Company</strong></td><td style="padding:8px 0;">${company}</td></tr>
            <tr style="background:#f8f9fa;"><td style="padding:8px;color:#666;"><strong>Website</strong></td><td style="padding:8px;"><a href="${website}" target="_blank">${website}</a></td></tr>
            <tr><td style="padding:8px 0;color:#666;"><strong>Phone</strong></td><td style="padding:8px 0;">${phone || '—'}</td></tr>
            <tr style="background:#f8f9fa;"><td style="padding:8px;color:#666;"><strong>Service</strong></td><td style="padding:8px;">${service}</td></tr>
            <tr><td style="padding:8px 0;color:#666;vertical-align:top;"><strong>Message</strong></td><td style="padding:8px 0;">${message || '—'}</td></tr>
          </table>
          <div style="margin-top:20px;padding:15px;background:#e8f5e9;border-radius:6px;border-left:4px solid #00c2a8;">
            <p style="margin:0;color:#2e7d32;"><strong>💡 Reply directly to this email</strong> — it goes straight to the prospect at ${email}</p>
          </div>
        </div>
        <p style="text-align:center;color:#999;font-size:12px;margin-top:15px;">Nova Dev · admin@novatvhub.com</p>
      </div>
    `,
  };

  // ── Auto-reply to the prospect ──
  const autoReplyMail = {
    from: `"Nova Dev" <admin@novatvhub.com>`,
    to:   email,
    subject: `✅ We received your audit request, ${fname}!`,
    html: `
      <div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;background:#f8f9fa;border-radius:8px;">
        <div style="background:#0d1b2a;padding:20px;border-radius:8px 8px 0 0;text-align:center;">
          <h2 style="color:#00c2a8;margin:0;">&lt;/&gt; Nova Dev</h2>
          <p style="color:#fff;margin:5px 0 0;">Web Dev &amp; Digital Marketing</p>
        </div>
        <div style="background:#fff;padding:30px;border-radius:0 0 8px 8px;border:1px solid #e0e0e0;">
          <h3 style="color:#0d1b2a;">Hi ${fname},</h3>
          <p style="color:#444;line-height:1.6;">Thank you for requesting your <strong>free website audit</strong>! We've received your request and our team is already reviewing <strong>${website}</strong>.</p>
          <div style="background:#e8f5e9;padding:15px;border-radius:6px;border-left:4px solid #00c2a8;margin:20px 0;">
            <p style="margin:0;color:#2e7d32;"><strong>📋 What happens next?</strong><br/>You'll receive your detailed PDF audit report within <strong>24 hours</strong>.</p>
          </div>
          <p style="color:#444;line-height:1.6;">If you have any urgent questions, reply to this email — we're here to help.</p>
          <div style="text-align:center;margin:25px 0;">
            <a href="https://novadev-official.netlify.app" style="background:#00c2a8;color:#fff;padding:12px 30px;border-radius:6px;text-decoration:none;font-weight:bold;">Visit Our Website</a>
          </div>
          <p style="color:#888;font-size:13px;">Best regards,<br/><strong>The Nova Dev Team</strong><br/>admin@novatvhub.com</p>
        </div>
      </div>
    `,
  };

  try {
    await transporter.sendMail(notifMail);
    await transporter.sendMail(autoReplyMail);
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: true }),
    };
  } catch (err) {
    console.error('SMTP Error:', err);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: false, error: err.message }),
    };
  }
};
