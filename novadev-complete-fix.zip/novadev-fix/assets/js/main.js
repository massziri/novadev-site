/* ============================================================
   Nova Dev — Main JavaScript (FIXED)
   Form handler using Netlify Forms (AJAX) + UI interactions
   ============================================================ */

(function() {
  'use strict';

  // ── Smooth Scroll ──────────────────────────────────────────
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // ── Netlify Forms Encode Helper ────────────────────────────
  function encode(data) {
    return Object.keys(data)
      .map(key => encodeURIComponent(key) + '=' + encodeURIComponent(data[key] || ''))
      .join('&');
  }

  // ── Form Submission Handler ────────────────────────────────
  const form = document.getElementById('auditForm');
  const btnSubmit = form ? form.querySelector('.btn-submit') : null;
  const successMsg = document.getElementById('successMsg');
  const errorMsg   = document.getElementById('errorMsg');

  if (form && btnSubmit) {
    form.addEventListener('submit', async function(e) {
      e.preventDefault();

      // Reset messages
      if (successMsg) successMsg.style.display = 'none';
      if (errorMsg)   errorMsg.style.display   = 'none';

      // Disable button and show loading state
      btnSubmit.disabled = true;
      const originalText = btnSubmit.textContent;
      btnSubmit.textContent = '⏳ Sending...';

      // Collect form data
      const formData = {
        'form-name': 'audit-request',
        fname:   form.fname.value.trim(),
        lname:   form.lname.value.trim(),
        email:   form.email.value.trim(),
        company: form.company.value.trim(),
        website: form.website.value.trim(),
        phone:   form.phone ? form.phone.value.trim() : '',
        service: form.service ? form.service.value : '',
        message: form.message ? form.message.value.trim() : ''
      };

      // Client-side validation
      if (!formData.fname || !formData.email) {
        showError('⚠️ Please fill in all required fields (First Name, Email).');
        resetButton(btnSubmit, originalText);
        return;
      }

      // Email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(formData.email)) {
        showError('⚠️ Please enter a valid email address.');
        resetButton(btnSubmit, originalText);
        return;
      }

      try {
        // ✅ Submit to Netlify Forms via AJAX (URL-encoded)
        const response = await fetch('/', {
          method:  'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body:    encode(formData)
        });

        if (response.ok) {
          // ✅ Success
          if (successMsg) {
            successMsg.style.display = 'block';
            successMsg.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }
          form.reset();
          setTimeout(() => resetButton(btnSubmit, originalText), 2000);

        } else {
          // Server error
          showError('⚠️ Something went wrong (status ' + response.status + '). Please try again or email us at admin@novatvhub.com');
          resetButton(btnSubmit, originalText);
        }

      } catch (error) {
        console.error('Form submission error:', error);
        showError('⚠️ Network error. Please check your connection and try again, or contact admin@novatvhub.com');
        resetButton(btnSubmit, originalText);
      }
    });
  }

  function showError(msg) {
    if (errorMsg) {
      errorMsg.innerHTML = msg;
      errorMsg.style.display = 'block';
    }
  }

  function resetButton(btn, text) {
    btn.disabled = false;
    btn.textContent = text;
  }

  // ── Stats Counter Animation ────────────────────────────────
  const stats = document.querySelectorAll('.stat .num');
  let animated = false;

  function animateCounters() {
    if (animated) return;

    stats.forEach(stat => {
      const rect = stat.getBoundingClientRect();
      if (rect.top < window.innerHeight && rect.bottom > 0) {
        animated = true;
        const text = stat.textContent;

        if (text.includes('+')) {
          animateCount(stat, 0, parseInt(text), 1500, '+');
        } else if (text.includes('%')) {
          animateCount(stat, 0, parseInt(text), 1500, '%');
        } else if (text.includes('×')) {
          animateCount(stat, 0, parseInt(text), 1500, '×');
        } else if (text.includes('h')) {
          animateCount(stat, 0, parseInt(text), 1500, 'h');
        }
      }
    });
  }

  function animateCount(element, start, end, duration, suffix) {
    const range     = end - start;
    const increment = range / (duration / 16);
    let   current   = start;

    const timer = setInterval(() => {
      current += increment;
      if (current >= end) {
        element.textContent = end + suffix;
        clearInterval(timer);
      } else {
        element.textContent = Math.floor(current) + suffix;
      }
    }, 16);
  }

  window.addEventListener('scroll', animateCounters, { passive: true });
  animateCounters();

})();
